import pygame
import random
import os


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, settings):
        super().__init__()
        self.image = pygame.Surface((5, 15))
        self.image.fill((0, 255, 255))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = settings.bullet_speed  # use settings

    def update(self):
        self.rect.y += self.speed
        if self.rect.bottom < 0:
            self.kill()


def load_strip(path, frame_w, frame_h, scale_to=None):
    sheet = pygame.image.load(path).convert_alpha()
    sheet_w, sheet_h = sheet.get_size()
    frames = []
    for x in range(0, sheet_w, frame_w):
        frame = sheet.subsurface(pygame.Rect(x, 0, frame_w, frame_h)).copy()
        if scale_to:
            frame = pygame.transform.smoothscale(frame, scale_to)
        frames.append(frame)
    return frames


class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, frames, fps=12):
        super().__init__()
        self.frames = frames
        self.fps = fps
        self.frame_i = 0
        self.image = self.frames[0]
        self.rect = self.image.get_rect()

        self._frame_ms = int(1000 / fps)
        self._last = pygame.time.get_ticks()

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self._last >= self._frame_ms:
            self._last = now
            self.frame_i = (self.frame_i + 1) % len(self.frames)
            old_center = self.rect.center
            self.image = self.frames[self.frame_i]
            self.rect = self.image.get_rect(center=old_center)

class Enemy(AnimatedSprite):
    def __init__(self, settings, is_special=False):
        self.settings = settings
        self.is_special = is_special
        self.hp = 1 if not is_special else 3

        if not is_special:
            frames = load_strip(
                os.path.join("assets", "enemy_spaceship_2.png"),
                frame_w=32, frame_h=32,
                scale_to=(48, 48)  # adjust size to taste
            )
        else:
            frames = load_strip(
                os.path.join("assets", "enemy_spaceship_5.png"),
                frame_w=32, frame_h=40,
                scale_to=(48, 60)  # taller source -> a bit taller
            )

        super().__init__(frames, fps=10)

        # spawn at random x
        self.rect = self.image.get_rect(x=random.randint(0, 900 - self.rect.width), y=-self.rect.height)
        self.speed = random.uniform(2.0, 4.0)

    def update(self):
        self.animate()
        self.rect.y += self.speed
        if self.rect.top > 600:
            self.kill()


class KnowledgeDrop(pygame.sprite.Sprite):
    _image = None  # class-level cache

    def __init__(self, x, y, available_info):
        super().__init__()

        if available_info:
            self.text = available_info.pop(0)
        else:
            self.text = "Сите лекции се научени! Подготви се за вирусот!"

        # Load the gem image only once
        if KnowledgeDrop._image is None:
            img = pygame.image.load(os.path.join("assets", "gem.png")).convert_alpha()
            KnowledgeDrop._image = pygame.transform.smoothscale(img, (28, 28))

        self.image = KnowledgeDrop._image
        self.rect = self.image.get_rect(center=(x, y))

    def update(self):
        self.rect.y += 2
        if self.rect.top > 600:
            self.kill()



