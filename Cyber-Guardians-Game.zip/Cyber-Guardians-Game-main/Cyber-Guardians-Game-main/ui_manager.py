import pygame
import os
import random
import math


class LayeredBackgroundBlue:
    def __init__(self, settings, folder="assets/layered", size=(900, 700)):
        self.settings = settings
        self.w, self.h = size
        self.t = 0.0

        def load(name, alpha=True):
            path = os.path.join(folder, name)
            img = pygame.image.load(path).convert_alpha() if alpha else pygame.image.load(path).convert()
            return pygame.transform.smoothscale(img, (self.w, self.h))

        def load_prop(name):
            path = os.path.join(folder, name)
            img = pygame.image.load(path).convert_alpha()
            return img  # keep original size; we place it explicitly

        # Base layers (fill screen)
        self.back = load("blue-back.png", alpha=False)
        self.stars = load("blue-stars.png", alpha=True)

        # Props (placed at positions; they "float")
        self.props = [
            {
                "img": load_prop("prop-planet-big.png"),
                "pos": (650, 90),
                "amp": 8,      # pixels
                "spd": 0.35,   # radians/sec-ish
                "ph": random.random() * 10.0,
                "xamp": 3
            },
            {
                "img": load_prop("prop-planet-small.png"),
                "pos": (140, 120),
                "amp": 6,
                "spd": 0.5,
                "ph": random.random() * 10.0,
                "xamp": 2
            },
            {
                "img": load_prop("asteroid-1.png"),
                "pos": (820, 360),
                "amp": 4,
                "spd": 0.9,
                "ph": random.random() * 10.0,
                "xamp": 2
            },
            {
                "img": load_prop("asteroid-2.png"),
                "pos": (250, 420),
                "amp": 5,
                "spd": 0.75,
                "ph": random.random() * 10.0,
                "xamp": 2
            },
        ]

    def update(self, dt_ms):
        self.t += dt_ms / 1000.0

    def draw(self, screen):
        # solid base
        screen.blit(self.back, (0, 0))

        # subtle star drift (vertical)
        y_star = int(math.sin(self.t * 0.5) * 2)
        screen.blit(self.stars, (0, y_star))

        # floating props
        for p in self.props:
            x0, y0 = p["pos"]
            y = y0 + math.sin(self.t * p["spd"] + p["ph"]) * p["amp"]
            x = x0 + math.sin(self.t * (p["spd"] * 0.7) + p["ph"]) * p["xamp"]
            screen.blit(p["img"], (int(x), int(y)))



class QuizSystem:
    def __init__(self, screen, settings):
        self.screen = screen
        self.settings = settings
        self.active = False
        self.showing_feedback = False
        self.correct = False
        self.questions_by_level = {
            1: [
                {"q": "Твојата лозинка е 'Admin123!'. Дали е тоа силна лозинка?",
                 "o": ["Да, има сè што треба.", "Не, прелесна е."], "c": 1,
                 "e": "Силна лозинка треба да има над 12 карактери, големи и мали букви, бројки и симболи."},
                {"q": "Што треба да провериш во адресата (URL) пред да внесеш податоци?",
                 "o": ["Дали има HTTPS и катинар.", "Дали боите се убави."], "c": 0,
                 "e": "HTTPS и иконата со катинар значат дека твојата врска е шифрирана и безбедна."},
                {"q": "Добиваш итен мејл од 'банката' дека профилот ти е блокиран. Што ќе направиш?",
                 "o": ["Ќе кликнам на линкот веднаш.", "Ќе ја повикам банката директно."], "c": 1,
                 "e": "Ова е Phishing! Банките никогаш не бараат лозинки преку итни мејлови со линкови."},
            ],
            2: [
                {"q": "Апликација бара дозвола за камера, а не е камера-апликација. Што правиш?",
                 "o": ["Ги одбивам дозволите.", "Давам дозвола, не е важно."], "c": 0,
                 "e": "Дај дозволи само ако има смисла. Непотребни дозволи = ризик."},
                {"q": "Добиваш порака: 'Освои телефон! Кликни тука!'. Што е тоа најверојатно?",
                 "o": ["Среќа!", "Измама/Scam линк."], "c": 1,
                 "e": "Премногу добро за да е вистина најчесто е измама."},
                {"q": "Кога инсталираш програма, што е најбезбедно?",
                 "o": ["Од официјална страна/Store.", "Од било кој линк."], "c": 0,
                 "e": "Официјални извори имаат помал ризик од малициозен софтвер."},
            ],
            3: [
                {"q": "Што е најдобро да направиш со важни фајлови?",
                 "o": ["Да направиш backup.", "Да ги чуваш само на едно место."], "c": 0,
                 "e": "Backup те спасува ако има вирус или ако нешто се избрише."},
                {"q": "Некоја страница бара да внесеш лозинка, ама URL-то е чудно. Што правиш?",
                 "o": ["Излегувам и проверувам официјален URL.", "Внесувам брзо."], "c": 0,
                 "e": "Лажни страници (phishing) често личат на вистински, но URL-то е различно."},
                {"q": "Кој е добар знак дека линкот е сомнителен?",
                 "o": ["Краток/чуден домен и многу бројки.", "Има нормално име."], "c": 0,
                 "e": "Сомнителни линкови често имаат чудни домени и непознати адреси."},
            ],
        }

        self.questions_pool = []
        self.load_for_level(self.settings.current_level)

        self.current_q = None

    def trigger_random(self):
        if len(self.questions_pool) > 0:
            self.active = True
            self.showing_feedback = False
            self.current_q = self.questions_pool.pop(random.randrange(len(self.questions_pool)))
        else: self.active = False

    def draw(self):
        if not self.active: return
        overlay = pygame.Surface((self.settings.screen_width, self.settings.screen_height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 230))
        self.screen.blit(overlay, (0, 0))

        panel_w, panel_h = 700, 420
        panel_x = (self.settings.screen_width - panel_w) // 2
        panel_y = (self.settings.screen_height - panel_h) // 2

        pygame.draw.rect(
            self.screen,
            (255, 255, 255),
            (panel_x, panel_y, panel_w, panel_h),
            border_radius=20
        )
        font = pygame.font.Font(self.settings.font_path, 18)
        if not self.showing_feedback:
            self.draw_text_wrapped(self.current_q["q"], panel_x + 50, panel_y + 50, panel_w - 100, font)

            for i, opt in enumerate(self.current_q["o"]):
                rect = pygame.Rect(panel_x + 50, panel_y + 220 + (i * 80), panel_w - 100, 60)
                pygame.draw.rect(self.screen, (100, 150, 255), rect, border_radius=10)
                txt = font.render(f"{i + 1}. {opt}", True, (255, 255, 255))
                self.screen.blit(txt, (180, 335 + (i * 80)))
        else:
            color = (0, 150, 0) if self.correct else (200, 0, 0)
            self.screen.blit(font.render("РЕЗУЛТАТ:", True, color), (150, 130))
            self.draw_text_wrapped(self.current_q["e"], 150, 180, 700, font)
            self.screen.blit(font.render("Притисни SPACE за продолжување!", True, (100, 100, 100)), (150, 450))

    def draw_text_wrapped(self, text, x, y, max_w, font):
        words = text.split(' '); line = ""
        for word in words:
            if font.size(line + word)[0] < max_w: line += word + " "
            else:
                self.screen.blit(font.render(line, True, (0, 0, 0)), (x, y))
                line = word + " "; y += 35
        self.screen.blit(font.render(line, True, (0, 0, 0)), (x, y))

    def load_for_level(self, level):
        # fresh copy for this level
        self.questions_pool = list(self.questions_by_level.get(level, []))
        self.current_q = None
        self.active = False
        self.showing_feedback = False


    def handle_event(self, event):
        if not self.active: return
        if self.showing_feedback:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE: self.active = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = event.pos
            if 150 < pos[0] < 750:
                if 320 < pos[1] < 380: self._check(0)
                elif 400 < pos[1] < 460: self._check(1)

    def _check(self, idx):
        self.correct = (idx == self.current_q["c"])
        if not self.correct: self.settings.shields = max(0, self.settings.shields - 1)
        self.showing_feedback = True

class Boss(pygame.sprite.Sprite):
    def __init__(self, settings, level=1):
        super().__init__()
        self.settings = settings
        self.max_hp = 100 + (level - 1) * 50
        self.current_hp = self.max_hp
        self.name = f"ГЛАВЕН ВИРУС - НИВО {level}"
        self.t = 0.0
        self.base_x = self.settings.screen_width // 2
        self.target_y = 80
        self.base_y = self.target_y
        self.level = level
        self.phase_y = 0.0
        self.phase_x = 0.0
        try:
            self.image = pygame.image.load(os.path.join('assets', 'monster1.png')).convert_alpha()
            self.image = pygame.transform.scale(self.image, (180, 180))
        except:
            self.image = pygame.Surface((150, 150)); self.image.fill((150, 0, 0))
        self.rect = self.image.get_rect(center=(self.settings.screen_width // 2, -100))

        self.dir = 1 # ПОПРАВЕНО: Сега има дефиниран атрибут 'dir'

    def update(self, player_x):
        if self.rect.y < self.target_y:
            self.rect.y += 2
        else:
            # advance time (no dt needed)
            self.t += 1 / 60.0  # assumes ~60 FPS; OK for this project

            margin = 50
            left = margin
            right = self.settings.screen_width - margin - self.rect.width
            cx = (left + right) / 2

            if self.level == 1:
                # Level 1: classic left-right (but smoother using sine)
                amp = (right - left) / 2
                x = cx + math.sin(self.t * 1.2) * amp
                self.rect.x = int(x)


            elif self.level == 2:

                amp_x = (right - left) / 2
                sx = 0.0
                if amp_x > 1:
                    sx = max(-1.0, min(1.0, (self.rect.x - cx) / amp_x))
                self.phase_x = math.asin(sx)

                # y phase so sin starts at current y (relative to target_y)
                sy = max(-1.0, min(1.0, (self.rect.y - self.target_y) / 25))
                self.phase_y = math.asin(sy)

                x = cx + math.sin(self.t * 1.4 + self.phase_x) * amp_x

                y = self.target_y + math.sin(self.t * 2.8 + self.phase_y) * 25

                self.rect.x = int(x)

                self.rect.y = int(y)

            else:
                # Level 3: “teleport dodge” every ~1.2 seconds + small bob
                y = self.target_y + math.sin(self.t * 2.0) * 12
                self.rect.y = int(y)

                if int(self.t * 60) % 72 == 0:  # ~every 72 frames
                    self.rect.x = random.randint(left, int(right))

    def draw(self, screen):
        screen.blit(self.image, self.rect)
        bar_w, bar_h = 300, 15
        bar_x = (self.settings.screen_width - bar_w) // 2
        bar_y = 10
        pygame.draw.rect(screen, (50, 50, 50), (bar_x, bar_y, bar_w, bar_h))
        pygame.draw.rect(screen, (255, 0, 0), (bar_x, bar_y, (self.current_hp / self.max_hp) * bar_w, bar_h))


def draw_boss_explanation(screen, settings):
    overlay = pygame.Surface((settings.screen_width, settings.screen_height), pygame.SRCALPHA)
    overlay.fill((0, 0, 60, 240))
    screen.blit(overlay, (0, 0))
    f = pygame.font.Font(settings.font_path, 26)
    lines = ["ВНИМАНИЕ: СИСТЕМОТ Е ПОД НАПАД!", "", "1. Вирусот е горе и постојано се движи.", "2. Не можеш да го допреш - само пукај!", "3. На секоја фаза мораш точно да одговориш на квиз.", "4. Ако згрешиш прашање, губиш живот.", "", "ПРИТИСНИ SPACE ЗА БОРБА!"]
    cx = settings.screen_width // 2
    for i, l in enumerate(lines):
        txt = f.render(l, True, (255, 255, 255))
        screen.blit(txt, (cx - txt.get_width() // 2, 120 + i * 45))

def draw_victory_screen(screen, settings):
    overlay = pygame.Surface((900, 700), pygame.SRCALPHA)
    overlay.fill((0, 60, 0, 240))
    screen.blit(overlay, (0, 0))
    f = pygame.font.Font(settings.font_path, 35)
    screen.blit(f.render("ЧЕСТИТКИ! СИСТЕМОТ Е БЕЗБЕДЕН!", True, (0, 255, 0)), (200, 200))
    screen.blit(f.render("Притисни 'R' за нова мисија", True, (255, 255, 255)), (280, 350))

def draw_scrolling_bg(screen, settings, scroll_y):
    try:
        bg = pygame.image.load(os.path.join('assets', 'background.jpg')).convert()
        bg = pygame.transform.scale(bg, (900, 700))
        rel_y = scroll_y % 700
        screen.blit(bg, (0, rel_y - 700)); screen.blit(bg, (0, rel_y))
    except: screen.fill(settings.bg_color)

def draw_instructions(screen, settings, is_overlay=False):
    if is_overlay:
        ov = pygame.Surface((900, 700), pygame.SRCALPHA); ov.fill((0,0,0,200)); screen.blit(ov, (0,0))
    f = pygame.font.Font(settings.font_path, 14)
    instr = [("УНИШТИ ГИ ВИРУСИТЕ И СОБЕРИ 5 ТОКЕНИ СО ЗНАЕЊЕ!", (255, 255, 255)), ("СИВИ: Обични вируси.", (168, 168, 168)), ("ЗЕЛЕНИ: Пукај ги 3 пати за да добиеш токен.", (108, 227, 52)), ("ЗЛАТНИ: Ова се лекции за безбедност.", (255, 215, 0)), ("ПРИТИСНИ SPACE ЗА СТАРТ", (255, 255, 255))]
    for i, (l, c) in enumerate(instr):
        screen.blit(f.render(l, True, c), (130, 180 + i * 50))

def draw_level_complete(screen, settings):
    overlay = pygame.Surface((900, 700), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 220))
    screen.blit(overlay, (0, 0))

    f_big = pygame.font.Font(settings.font_path, 40)
    f = pygame.font.Font(settings.font_path, 24)

    screen.blit(f_big.render(f"НИВО {settings.current_level -1} Е СОВЛАДАНО!", True, (0, 255, 255)), (170, 200))
    screen.blit(f.render("Притисни SPACE за следно ниво", True, (255, 255, 255)), (245, 320))
