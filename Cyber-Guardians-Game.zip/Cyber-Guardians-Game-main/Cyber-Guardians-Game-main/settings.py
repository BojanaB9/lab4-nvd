import pygame
import os
class GameSettings:
    def __init__(self):
        self.screen_width = 900
        self.screen_height = 700
        self.reset_game()

    def reset_game(self):
        self.player_speed = 6
        self.bullet_speed = -8
        self.enemy_speed = 1
        self.score = 0
        self.knowledge_points = 0
        self.shields = 3
        self.correct_count = 0
        self.current_level = 1
        self.game_active = True
        self.show_instructions = True
        self.boss_active = False
        self.font_path = os.path.join("assets", "PressStart2P-Regular.ttf")
        self.bg_color = (10, 10, 30)

    def next_level(self):
        self.current_level += 1
        self.enemy_speed += 1
        self.boss_active = False