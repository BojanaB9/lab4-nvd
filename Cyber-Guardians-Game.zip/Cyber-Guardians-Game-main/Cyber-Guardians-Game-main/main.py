import pygame, sys, random, os
from settings import GameSettings
from entities import Bullet, Enemy, KnowledgeDrop
from ui_manager import QuizSystem, Boss, draw_instructions, draw_scrolling_bg, draw_boss_explanation, draw_victory_screen, draw_level_complete, LayeredBackgroundBlue
from player import Player

def main():
    pygame.init()
    configs = GameSettings()
    screen = pygame.display.set_mode((900, 700))
    pygame.display.set_caption("Cyber Guardians")
    clock = pygame.time.Clock()
    tint_overlay = pygame.Surface((900, 700), pygame.SRCALPHA)
    tint_overlay.fill((10, 20, 50, 80))  # dark blue with transparency

    bg = LayeredBackgroundBlue(configs, folder="assets/layered", size=(900, 700))


    knowledge_by_level = {
        1: [
            "Силна лозинка треба да има над 12 карактери, големи букви и симболи како @ или #.",
            "2FA бара код од твојот телефон, што спречува влез дури и ако ја знаат лозинката.",
            "Провери ја адресата! Ако пишува 'g0ogle.com' наместо 'google.com', тоа е лажна страна.",
            "Јавните Wi-Fi мрежи се небезбедни за купување бидејќи хакерите можат да ги пресретнат податоците.",
            "Никогаш не кликај на 'Преземи' ако прозорецот вели дека компјутерот ти е веднаш заразен."
        ],
        2: [
            "Апликациите бараат дозволи — дај само тие што се потребни (камера/микрофон).",
            "Не отворај сомнителни линкови од пораки: тоа може да е scam.",
            "Инсталирај игри/апликации само од официјален Store или официјална страница.",
            "Ажурирањата (updates) поправат безбедносни дупки — инсталирај ги.",
            "Не споделувај лозинки со другари, дури и ако се 'само за малку'."
        ],
        3: [
            "Backup копија те спасува ако вирус ги заклучи фајловите (ransomware).",
            "Лажни страници може да изгледаат исто — секогаш проверувај URL.",
            "Не внесувај лични податоци на страници што немаат доверба/HTTPS.",
            "Користи различни лозинки за различни апликации.",
            "Кога нешто ти изгледа сомнително — прашај возрасен/наставник."
        ],
    }

    knowledge_pool = list(knowledge_by_level[configs.current_level])

    def init_game():
        p = Player(configs); return p, pygame.sprite.Group(p), pygame.sprite.Group(), pygame.sprite.Group(), pygame.sprite.Group(), QuizSystem(screen, configs), None

    player, all_sprites, bullets, enemies, drops, quiz, boss = init_game()
    SPAWN_ENEMY = pygame.USEREVENT + 1

    def apply_level_tuning():
        nonlocal knowledge_pool
        # spawn faster each level (1000, 850, 700) with a cap
        spawn_ms = max(700, 1000 - (configs.current_level - 1) * 150)
        pygame.time.set_timer(SPAWN_ENEMY, spawn_ms)

        # reset the level lesson pool
        knowledge_pool = list(knowledge_by_level[configs.current_level])

        # reset quiz for this level (requires you to add quiz.load_for_level in ui_manager)
        quiz.load_for_level(configs.current_level)

    apply_level_tuning()

    #scroll_y = 0
    msg_timer = 0
    knowledge_msg = ""
    boss_intro = False

    while True:
        dt_ms = clock.tick(60)
        bg.update(dt_ms)
        bg.draw(screen)
        screen.blit(tint_overlay, (0, 0))

        #if not quiz.active and configs.game_active: scroll_y += 1

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if not configs.game_active or configs.show_instructions:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        configs.reset_game()
                        player, all_sprites, bullets, enemies, drops, quiz, boss = init_game()
                        boss_intro = False
                        apply_level_tuning()

                    elif event.key == pygame.K_SPACE and configs.show_instructions: configs.show_instructions = False
            if not quiz.active and configs.game_active and not configs.show_instructions:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    b = Bullet(player.rect.centerx, player.rect.top, configs)
                    bullets.add(b)
                    all_sprites.add(b)
                if event.type == SPAWN_ENEMY and not configs.boss_active:
                    enemies.add(Enemy(configs, random.random() < 0.2))
            quiz.handle_event(event)

        if configs.show_instructions: draw_instructions(screen, configs, True)
        elif not configs.game_active:
            if getattr(configs, 'victory', False): draw_victory_screen(screen, configs)
            else:
                ov = pygame.Surface((900, 700), pygame.SRCALPHA); ov.fill((40,0,0,220)); screen.blit(ov, (0,0))
                f = pygame.font.Font("assets/PressStart2P-Regular.ttf", 18); screen.blit(f.render("ИГРАТА ЗАВРШИ! ПРИТИСНИ 'R' ЗА РЕСТАРТ", True, (255,255,255)), (250, 280))
        else:
            if not quiz.active:
                player.update(pygame.key.get_pressed()); bullets.update(); enemies.update(); drops.update()
                if pygame.sprite.spritecollide(player, enemies, True):
                    configs.shields = max(0, configs.shields - 1);
                    if configs.shields <= 0: configs.game_active = False
                for d in pygame.sprite.spritecollide(player, drops, True):
                    knowledge_msg = d.text; msg_timer = 180; configs.knowledge_points += 1; configs.score += 50
                for b in bullets:
                    hits = pygame.sprite.spritecollide(b, enemies, False)
                    for e in hits:
                        e.hp -= 1; b.kill()
                        if e.hp <= 0:
                            if e.is_special:
                                drop = KnowledgeDrop(e.rect.centerx, e.rect.centery, knowledge_pool); drops.add(drop); all_sprites.add(drop)
                            configs.score += 10; e.kill()
                if configs.knowledge_points >= 5 and not configs.boss_active:
                    if not boss_intro:
                        draw_boss_explanation(screen, configs); pygame.display.flip()
                        wait = True
                        while wait:
                            for e in pygame.event.get():
                                if e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE: wait = False
                                if e.type == pygame.QUIT: pygame.quit(); sys.exit()
                        boss_intro = True
                    configs.boss_active = True
                    boss = Boss(configs, level=configs.current_level)

                if configs.boss_active and boss:
                    boss.update(player.rect.centerx)
                    if pygame.sprite.spritecollide(boss, bullets, True):
                        boss.current_hp -= 5
                        if boss.current_hp > 0 and boss.current_hp % 20 == 0: quiz.trigger_random()
                        if boss.current_hp <= 0:
                            if configs.current_level >= 3:
                                configs.victory = True
                                configs.game_active = False
                            else:
                                # advance to next level
                                configs.next_level()
                                configs.knowledge_points = 0
                                configs.boss_active = False
                                boss = None
                                boss_intro = False

                                # clear current objects
                                bullets.empty()
                                enemies.empty()
                                drops.empty()

                                apply_level_tuning()

                                # show level complete screen (wait for SPACE)
                                draw_level_complete(screen, configs)
                                pygame.display.flip()

                                waiting = True
                                while waiting:
                                    for e in pygame.event.get():
                                        if e.type == pygame.QUIT:
                                            pygame.quit()
                                            sys.exit()
                                        if e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE:
                                            waiting = False

            all_sprites.draw(screen); enemies.draw(screen); drops.draw(screen)
            if boss: boss.draw(screen)
            f_hud = pygame.font.Font("assets/PressStart2P-Regular.ttf", 16,)
            screen.blit(
                f_hud.render(
                    f"НИВО: {configs.current_level} | ПОЕНИ: {configs.score} | ЖИВОТИ: {configs.shields} | ЗНАЕЊЕ: {configs.knowledge_points}/5",
                    True, (255, 255, 255)
                ),
                (20, 20)
            )

            if msg_timer > 0:
                bf = pygame.font.Font("assets/PressStart2P-Regular.ttf", 18); txt = bf.render(knowledge_msg, True, (255, 215, 0))
                rect = txt.get_rect(center=(450, 520)); pygame.draw.rect(screen, (0, 0, 0), rect.inflate(30, 15), border_radius=10); screen.blit(txt, rect); msg_timer -= 1
            quiz.draw()
        pygame.display.flip()





if __name__ == "__main__": main()